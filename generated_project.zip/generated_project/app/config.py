class Settings:
    SECRET_KEY = "secret_key_here"
    DATABASE_URL = "sqlite:///database.db"
    JWT_TOKEN_EXPIRE_MINUTES = 30